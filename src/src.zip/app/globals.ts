// globals.ts
'use strict';



export const rootURL='http://localhost:3000/';
