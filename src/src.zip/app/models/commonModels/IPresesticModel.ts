export interface IPresesticModel {
    WhereCondition: string;
    Includes: string;
    Order: string;
    PageIndex: number;
    PageSize: number;
    NoorId: number;
}
