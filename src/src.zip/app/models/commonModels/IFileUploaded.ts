export interface IFileUploaded {
    ID: number;
    Name: string;
}
