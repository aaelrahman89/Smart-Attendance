export interface IResultDelete {
    Success: boolean;
    Message: string;
    id: number;
}
