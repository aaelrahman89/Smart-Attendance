import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { IndexComponent } from './components/index/index.component';
import { AttendanceRecordComponent } from './components/attendance-record/attendance-record.component';
import { ManageAttComponent } from './components/manage-att/manage-att.component';
import { ManageREQComponent } from './components/manage-req/manage-req.component';
import { HelpComponent } from './components/help/help.component';
import { StudentComponent } from './components/student/student.component';


const routes: Routes = [
  {path: '', component:  IndexComponent},
  // {path: ':id', component:  IndexComponent},
      {path: 'AttendanceRecord', component:  AttendanceRecordComponent},
      {path: 'ManageAtt', component:  ManageAttComponent},
      {path: 'ManageREQ', component:  ManageREQComponent},
      {path: 'Help', component:  HelpComponent},
      {path: 'student', component: StudentComponent},
      {path: 'student/:Id', component: StudentComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
