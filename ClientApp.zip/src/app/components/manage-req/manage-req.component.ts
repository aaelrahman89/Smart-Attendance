import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-req',
  templateUrl: './manage-req.component.html',
  styleUrls: ['./manage-req.component.css']
})
export class ManageREQComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
