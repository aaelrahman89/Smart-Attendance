
export interface CollegeDTO
{
    id: number;
    collegeCode: number;
    nameAr: string;
    nameEn: string;
    isActive: boolean;
  }