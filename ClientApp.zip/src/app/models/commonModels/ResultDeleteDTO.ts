export class ResultDeleteDTO {
    Success: boolean = false;
    Message: string = '';
}
