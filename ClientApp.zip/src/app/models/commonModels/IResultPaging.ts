export interface IResultPaging {
    Pagelength: number;
    RecordsTotal: number;
    RecordsFiltered: number;
}
