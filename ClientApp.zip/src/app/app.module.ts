import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap'; //botstrap
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { FormsModule } from '@angular/forms'
import { AttendanceRecordComponent } from './components/attendance-record/attendance-record.component';
import { ManageAttComponent } from './components/manage-att/manage-att.component';
import { ManageREQComponent } from './components/manage-req/manage-req.component';
import { HelpComponent } from './components/help/help.component';
import { IndexComponent } from './components/index/index.component';
import {MatIconModule} from '@angular/material/icon';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { StudentComponent } from './components/student/student.component';
import { DataTablesModule } from 'angular-datatables';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    AttendanceRecordComponent,
    ManageAttComponent,
    ManageREQComponent,
    HelpComponent,
    IndexComponent,
    StudentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule, //botstrap
    FontAwesomeModule,
    MatIconModule,
    FormsModule,
    BrowserAnimationsModule,
    DataTablesModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
