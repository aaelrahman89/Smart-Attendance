export class SeesionModel<T> {
    UserId: number = null;
    Key: string = '';
    Storage: T;
}