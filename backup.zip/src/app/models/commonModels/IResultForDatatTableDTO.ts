import { IResultPaging } from './IResultPaging';

export interface IResultForDatatTableDTO<T> {
    list: T[];
    resultPaging: IResultPaging;
}
