export class FilterModel {
    pageIndex: number = 0;
    pageCount: number = 0;
    pagelength: number = 0;
    totalCount: number = 0;
    WhereCondition: string = "";
    Includes:string ="";
}
