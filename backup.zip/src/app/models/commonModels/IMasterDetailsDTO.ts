export interface IMasterDetailsDTO<Master, Details> {
    master: Master;
    details: Details[];
}
