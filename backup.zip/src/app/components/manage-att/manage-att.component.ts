import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-att',
  templateUrl: './manage-att.component.html',
  styleUrls: ['./manage-att.component.css']
})
export class ManageAttComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
