import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-attendance-record',
  templateUrl: './attendance-record.component.html',
  styleUrls: ['./attendance-record.component.css']
})
export class AttendanceRecordComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
